import { useState } from 'react'
import Layout from './components/Layout'
import ChatWidget from './components/ChatWidget'
import FileIngestion from './components/FileIngestion'

function App() {
  const [activeTab, setActiveTab] = useState('chat')

  return (
    <Layout activeTab={activeTab} onTabChange={setActiveTab}>
      {activeTab === 'chat' && <ChatWidget />}
      {activeTab === 'ingest' && <FileIngestion />}
    </Layout>
  )
}

export default App

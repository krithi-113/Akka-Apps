const BASE_URL = '';

export async function askQuestion(question, sessionId) {
  const response = await fetch(`${BASE_URL}/graph-rag/ask`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ question, sessionId: sessionId || '' })
  });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  return response.json();
}

export async function ingestData(jsonData) {
  const response = await fetch(`${BASE_URL}/graph-rag/ingest`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(jsonData)
  });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  return response.json();
}

import { useState } from 'react'
import { ingestData } from '../api/client'

export default function FileIngestion() {
  const [file, setFile] = useState(null)
  const [preview, setPreview] = useState(null)
  const [jsonData, setJsonData] = useState(null)
  const [status, setStatus] = useState(null)
  const [loading, setLoading] = useState(false)

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0]
    if (!selectedFile) return

    setFile(selectedFile)
    setStatus(null)

    const reader = new FileReader()
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target.result)
        if (!parsed.insert || !Array.isArray(parsed.insert)) {
          setStatus({ type: 'error', message: 'Invalid format: expected { "insert": [...] }' })
          setPreview(null)
          setJsonData(null)
          return
        }

        const entityCounts = {}
        parsed.insert.forEach(record => {
          const id = record['@id'] || 'unknown'
          const type = id.includes('/') ? id.split('/')[0] : 'Unknown'
          entityCounts[type] = (entityCounts[type] || 0) + 1
        })

        setJsonData(parsed)
        setPreview({
          totalRecords: parsed.insert.length,
          entityCounts,
          ledger: parsed.ledger || '(not specified)'
        })
      } catch (err) {
        setStatus({ type: 'error', message: 'Invalid JSON: ' + err.message })
        setPreview(null)
        setJsonData(null)
      }
    }
    reader.readAsText(selectedFile)
  }

  const handleSubmit = async () => {
    if (!jsonData || loading) return
    setLoading(true)
    setStatus(null)

    try {
      const result = await ingestData(jsonData)
      if (result.success) {
        setStatus({ type: 'success', message: `${result.message} (${result.recordCount} records)` })
      } else {
        setStatus({ type: 'error', message: result.message })
      }
    } catch (err) {
      setStatus({ type: 'error', message: 'Upload failed: ' + err.message })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="bg-white rounded-lg shadow p-6 max-w-2xl mx-auto">
      <h2 className="text-lg font-semibold text-gray-800 mb-4">Ingest Data File</h2>
      <p className="text-sm text-gray-500 mb-6">
        Upload a JSON file in the seed data format (with &quot;ledger&quot; and &quot;insert&quot; array).
        Properties will be automatically namespace-prefixed and entity references resolved.
      </p>

      {/* File picker */}
      <div className="mb-6">
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Select JSON File
        </label>
        <input
          type="file"
          accept=".json"
          onChange={handleFileChange}
          className="block w-full text-sm text-gray-500
            file:mr-4 file:py-2 file:px-4
            file:rounded-md file:border-0
            file:text-sm file:font-semibold
            file:bg-blue-50 file:text-blue-700
            hover:file:bg-blue-100"
        />
      </div>

      {/* Preview */}
      {preview && (
        <div className="mb-6 p-4 bg-gray-50 rounded-lg">
          <h3 className="text-sm font-medium text-gray-700 mb-2">File Preview</h3>
          <p className="text-sm text-gray-600">Ledger: {preview.ledger}</p>
          <p className="text-sm text-gray-600">Total Records: {preview.totalRecords}</p>
          <div className="mt-2">
            <p className="text-sm font-medium text-gray-700">Entity Types:</p>
            <ul className="text-sm text-gray-600 ml-4 list-disc">
              {Object.entries(preview.entityCounts).map(([type, count]) => (
                <li key={type}>{type}: {count}</li>
              ))}
            </ul>
          </div>
        </div>
      )}

      {/* Submit */}
      <button
        onClick={handleSubmit}
        disabled={!jsonData || loading}
        className="w-full py-2 px-4 bg-blue-600 text-white rounded-lg hover:bg-blue-700
          disabled:opacity-50 disabled:cursor-not-allowed text-sm font-medium"
      >
        {loading ? 'Uploading...' : 'Upload and Ingest'}
      </button>

      {/* Status */}
      {status && (
        <div className={`mt-4 p-3 rounded-lg text-sm ${
          status.type === 'success'
            ? 'bg-green-50 text-green-800 border border-green-200'
            : 'bg-red-50 text-red-800 border border-red-200'
        }`}>
          {status.message}
        </div>
      )}
    </div>
  )
}

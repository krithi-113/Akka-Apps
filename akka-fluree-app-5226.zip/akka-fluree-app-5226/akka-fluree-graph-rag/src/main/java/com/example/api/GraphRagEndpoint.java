package com.example.api;

import akka.javasdk.annotations.Acl;
import akka.javasdk.annotations.http.Get;
import akka.javasdk.annotations.http.HttpEndpoint;
import akka.javasdk.annotations.http.Post;
import akka.javasdk.client.ComponentClient;
import com.example.application.SupplyChainGraphRagAgent;

import java.util.UUID;

/**
 * Simple HTTP API for asking the SupplyChainGraphRagAgent.
 */

@Acl(allow = @Acl.Matcher(principal = Acl.Principal.INTERNET))
@HttpEndpoint("/graph-rag")
public class GraphRagEndpoint {

  public record AskRequest(String question, String sessionId) {}
  public record AskResponse(String sessionId, String answer) {}

  private final ComponentClient componentClient;

  public GraphRagEndpoint(ComponentClient componentClient) {
    this.componentClient = componentClient;
  }

//   @Get("/health")
// public String health() {
//     try {
//       boolean flureeHealthy = flureeClient.isHealthy();
//       return flureeHealthy ? "OK" : "UNHEALTHY";
//     } catch (Exception e) {
//       return "ERROR: " + e.getMessage();
//     }
// }

  @Post("/ask")
  public AskResponse ask(AskRequest request) {
    String sessionId =
        (request.sessionId() == null || request.sessionId().isBlank())
            ? UUID.randomUUID().toString()
            : request.sessionId();

    String answer = componentClient
        .forAgent()
        .inSession(sessionId)
        .method(SupplyChainGraphRagAgent::query)
        .invoke(request.question());

    return new AskResponse(sessionId, answer);
  }
}

package com.example.application;

import akka.javasdk.agent.Agent;
import akka.javasdk.annotations.Component;
import akka.javasdk.annotations.Description;
import akka.javasdk.annotations.FunctionTool;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component(id = "supplychain-graphrag-agent")
public class SupplyChainGraphRagAgent extends Agent {
  private static final Logger log = LoggerFactory.getLogger(SupplyChainGraphRagAgent.class);
  private static final ObjectMapper MAPPER = new ObjectMapper();
  private final FlureeClient fluree;

  private static final String SYSTEM_MESSAGE = """
    You are a supply chain analyst assistant with access to a Fluree graph database.
   
    Available tools:
    - getAllProducts: Get all products in the database
    - getAllCountries: Get all countries in the database
    - getAllSuppliers: Get all suppliers in the database
    - findProductsByHtsCode: Find products by HTS code
    - findSuppliersByCountry: Find suppliers by country code
    - getProductBOM: Get bill of materials for a product
   
    When answering questions:
    1. Use the appropriate tool to query Fluree
    2. Parse the JSON response
    3. Provide a clear, concise answer with key details
    4. If data is missing, ask for clarification
   
    The tools return JSON data. Parse it and present it in a user-friendly format.
    """;

  public SupplyChainGraphRagAgent(FlureeClient fluree) {
    this.fluree = fluree;
  }

  public Effect<String> query(String question) {
    return effects()
        .systemMessage(SYSTEM_MESSAGE)
        .userMessage(question)
        .thenReply();
  }

  // ✅ FIXED: Return JsonNode instead of String
  @FunctionTool(description = "Get all products from the database")
  public JsonNode getAllProducts() {
    log.info("Tool getAllProducts called");
    try {
      String jsonString = fluree.getAllProducts();
      return MAPPER.readTree(jsonString);
    } catch (Exception e) {
      log.error("Error getting all products", e);
      return MAPPER.createObjectNode()
          .put("error", "Failed to retrieve products: " + e.getMessage());
    }
  }

  @FunctionTool(description = "Get all countries from the database")
  public JsonNode getAllCountries() {
    log.info("Tool getAllCountries called");
    try {
      String jsonString = fluree.getAllCountries();
      return MAPPER.readTree(jsonString);
    } catch (Exception e) {
      log.error("Error getting all countries", e);
      return MAPPER.createObjectNode()
          .put("error", "Failed to retrieve countries: " + e.getMessage());
    }
  }

  @FunctionTool(description = "Get all suppliers from the database")
  public JsonNode getAllSuppliers() {
    log.info("Tool getAllSuppliers called");
    try {
      String jsonString = fluree.getAllSuppliers();
      return MAPPER.readTree(jsonString);
    } catch (Exception e) {
      log.error("Error getting all suppliers", e);
      return MAPPER.createObjectNode()
          .put("error", "Failed to retrieve suppliers: " + e.getMessage());
    }
  }

  @FunctionTool(description = "Find products by HTS classification code")
  public JsonNode findProductsByHtsCode(
      @Description("HTS code to search for (e.g. '8517.12.00')") String htsCode) {
    log.info("Tool findProductsByHtsCode called with: {}", htsCode);
    try {
      String jsonString = fluree.findProductsByHtsCode(htsCode);
      return MAPPER.readTree(jsonString);
    } catch (Exception e) {
      log.error("Error finding products by HTS code", e);
      return MAPPER.createObjectNode()
          .put("error", "Failed to find products: " + e.getMessage());
    }
  }

  @FunctionTool(description = "Find suppliers from a specific country")
  public JsonNode findSuppliersByCountry(
      @Description("ISO country code (e.g. 'CN' for China, 'US' for USA)") String countryCode) {
    log.info("Tool findSuppliersByCountry called with: {}", countryCode);
    try {
      String jsonString = fluree.findSuppliersByCountry(countryCode);
      return MAPPER.readTree(jsonString);
    } catch (Exception e) {
      log.error("Error finding suppliers by country", e);
      return MAPPER.createObjectNode()
          .put("error", "Failed to find suppliers: " + e.getMessage());
    }
  }

  @FunctionTool(description = "Get bill of materials (BOM) for a product")
  public JsonNode getProductBOM(
      @Description("Product ID (e.g. 'ex:product-p1000')") String productId) {
    log.info("Tool getProductBOM called with: {}", productId);
    try {
      String jsonString = fluree.getProductBOM(productId);
      return MAPPER.readTree(jsonString);
    } catch (Exception e) {
      log.error("Error getting product BOM", e);
      return MAPPER.createObjectNode()
          .put("error", "Failed to get BOM: " + e.getMessage());
    }
  }
}
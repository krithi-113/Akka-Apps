package com.example.application;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.typesafe.config.Config;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.*;

public class FlureeClient {
  private static final Logger log = LoggerFactory.getLogger(FlureeClient.class);
  private static final ObjectMapper MAPPER = new ObjectMapper();

  private final HttpClient http;
  private final String baseUrl ;//= "https://data.flur.ee/fluree";
  private final String bearerToken;
  private final String ledger;
  private final String namespace;

  public FlureeClient(Config config) {
    var cfg = config.getConfig("fluree");
   
    this.baseUrl = cfg.getString("base-url");
      this.bearerToken = cfg.hasPath("bearer-token") && !cfg.getString("bearer-token").isEmpty()
        ? cfg.getString("bearer-token")
        : null;
    this.ledger = cfg.getString("ledger");
    this.namespace = cfg.hasPath("namespace")
        ? cfg.getString("namespace")
        : "https://example.org/";
    this.http = HttpClient.newBuilder()
        .connectTimeout(Duration.ofSeconds(10))
        .build();

    log.info("✅ FlureeClient initialized");
    log.info("📡 Ledger: {}", ledger);
    log.info("🔗 Base URL: {}", baseUrl);
  }

  // ==========================================
  // QUERY ENDPOINT
  // ==========================================
 
  /**
   * Execute a FlureeQL query
   * ✅ FIXED: Create mutable copy to avoid ImmutableCollections error
   */
  public String query(Map<String, Object> flureeQuery) {
    // ✅ Create a MUTABLE HashMap from the immutable Map.of()
    Map<String, Object> mutableQuery = new HashMap<>(flureeQuery);
    mutableQuery.put("from", ledger);
    mutableQuery.putIfAbsent("@context", Map.of("ex", namespace));
   
    return post(baseUrl + "/query", mutableQuery);
  }

  /**
   * Get all products
   */
  public String getAllProducts() {
    log.info("📦 Getting all products");
    Map<String, Object> query = Map.of(
        "select", Map.of("?product", List.of("*")),
        "where", List.of(
            Map.of("@id", "?product", "@type", "ex:Product")
        )
    );
    return query(query);
  }

  /**
   * Find products by HTS code
   */
  public String findProductsByHtsCode(String htsCode) {
    log.info("🔍 Finding products with HTS code: {}", htsCode);
    Map<String, Object> query = Map.of(
        "select", Map.of(
            "?product", List.of("*"),
            "?hts", List.of("ex:code")
        ),
        "where", List.of(
            Map.of(
                "@id", "?product",
                "@type", "ex:Product",
                "ex:htsCode", "?hts"
            ),
            Map.of(
                "@id", "?hts",
                "ex:code", htsCode
            )
        )
    );
    return query(query);
  }

  /**
   * Find suppliers by country
   */
  public String findSuppliersByCountry(String countryCode) {
    log.info("🏭 Finding suppliers from country: {}", countryCode);
    Map<String, Object> query = Map.of(
        "select", Map.of(
            "?supplier", List.of("*"),
            "?country", List.of("ex:name", "ex:code")
        ),
        "where", List.of(
            Map.of(
                "@id", "?supplier",
                "@type", "ex:Supplier",
                "ex:country", "?country"
            ),
            Map.of(
                "@id", "?country",
                "ex:code", countryCode
            )
        )
    );
    return query(query);
  }

  /**
   * Get all countries
   */
  public String getAllCountries() {
    log.info("🌍 Getting all countries");
    Map<String, Object> query = Map.of(
        "select", Map.of("?country", List.of("*")),
        "where", List.of(
            Map.of("@id", "?country", "@type", "ex:Country")
        )
    );
    return query(query);
  }

  /**
   * Get all suppliers
   */
  public String getAllSuppliers() {
    log.info("🏭 Getting all suppliers");
    Map<String, Object> query = Map.of(
        "select", Map.of("?supplier", List.of("*")),
        "where", List.of(
            Map.of("@id", "?supplier", "@type", "ex:Supplier")
        )
    );
    return query(query);
  }

  /**
   * Get BOM for a product
   */
  public String getProductBOM(String productId) {
    log.info("📋 Getting BOM for product: {}", productId);
    Map<String, Object> query = Map.of(
        "select", Map.of(
            "?bom", List.of("*"),
            "?ingredient", List.of("*")
        ),
        "where", List.of(
            Map.of(
                "@id", "?bom",
                "@type", "ex:BOM",
                "ex:product", Map.of("@id", productId),
                "ex:ingredient", "?ingredient"
            )
        )
    );
    return query(query);
  }

  /**
   * Get all recipes
   */
  public String getAllRecipes() {
    log.info("📋 Getting all recipes");
    Map<String, Object> query = Map.of(
        "select", Map.of("?recipe", List.of("*")),
        "where", List.of(
            Map.of("@id", "?recipe", "@type", "ex:Recipe")
        )
    );
    return query(query);
  }

  /**
   * Get all HTS codes
   */
  public String getAllHTSCodes() {
    log.info("📊 Getting all HTS codes");
    Map<String, Object> query = Map.of(
        "select", Map.of("?hts", List.of("*")),
        "where", List.of(
            Map.of("@id", "?hts", "@type", "ex:HTSCode")
        )
    );
    return query(query);
  }

  // ==========================================
  // TRANSACT ENDPOINT (Write Data)
  // ==========================================
 
  /**
   * Insert new data into Fluree
   * ✅ FIXED: Create mutable map
   */
  public String transact(List<Map<String, Object>> insertData) {
    log.info("💾 Inserting {} records", insertData.size());
   
    Map<String, Object> transactBody = new HashMap<>(); // ✅ Mutable
    transactBody.put("@context", Map.of("ex", namespace));
    transactBody.put("ledger", ledger);
    transactBody.put("insert", insertData);
   
    return post(baseUrl + "/transact", transactBody);
  }

  /**
   * Store a compliance event
   */
  public String storeComplianceEvent(String eventId, String title, String description,
                                      List<String> affectedHtsCodes, String severity) {
    log.info("⚠️  Storing compliance event: {}", eventId);
   
    List<Map<String, Object>> insert = List.of(
        Map.of(
            "@id", "ComplianceEvent/" + eventId,
            "@type", "ex:ComplianceEvent",
            "ex:eventId", eventId,
            "ex:title", title,
            "ex:description", description,
            "ex:affectedHtsCodes", affectedHtsCodes,
            "ex:severity", severity,
            "ex:timestamp", System.currentTimeMillis()
        )
    );
   
    return transact(insert);
  }

  // ==========================================
  // HISTORY ENDPOINT
  // ==========================================
 
  /**
   * Get historical versions of an entity
   */
  public String getHistory(String entityId) {
    log.info("📜 Getting history for: {}", entityId);
   
    Map<String, Object> historyQuery = new HashMap<>(); // ✅ Mutable
    historyQuery.put("from", ledger);
    historyQuery.put("@context", Map.of("ex", namespace));
    historyQuery.put("history", entityId);
   
    return post(baseUrl + "/history", historyQuery);
  }

  // ==========================================
  // HELPER METHODS
  // ==========================================
 
private String post(String url, Object bodyObject) {
    try {
      String body = MAPPER.writeValueAsString(bodyObject);
      log.info("🔹 Sending to Fluree URL: {}", url);  // ✅ ADD
      log.info("🔹 Request body: {}", body);          // ✅ ADD
     
      HttpRequest request = HttpRequest.newBuilder()
          .uri(URI.create(url))
          .timeout(Duration.ofSeconds(30))
          .header("Content-Type", "application/json")
          .POST(HttpRequest.BodyPublishers.ofString(body))
          .build();
     
      HttpResponse<String> response = http.send(request, HttpResponse.BodyHandlers.ofString());
     
      log.info("🔹 Response status: {}", response.statusCode());  // ✅ ADD
      log.info("🔹 Response body: {}", response.body());          // ✅ ADD
     
      if (response.statusCode() < 200 || response.statusCode() >= 300) {
        log.error("❌ Fluree error: {} - {}", response.statusCode(), response.body());
        throw new RuntimeException("Fluree HTTP " + response.statusCode() + " => " + response.body());
      }
     
      return response.body();
     
    } catch (IOException | InterruptedException e) {
      Thread.currentThread().interrupt();
      log.error("❌ Exception calling Fluree", e);  // ✅ ADD
      throw new RuntimeException("Failed calling Fluree: " + url, e);
    }
}

  /**
   * Health check
   */
  public boolean isHealthy() {
    try {
      Map<String, Object> testQuery = Map.of(
          "selectDistinct", "?type",
          "where", List.of(
              Map.of("@id", "?s", "@type", "?type")
          )
      );
     
      String result = query(testQuery);
      return result != null && !result.isEmpty();
     
    } catch (Exception e) {
      log.error("❌ Health check failed", e);
      return false;
    }
  }
}
package com.example;

import akka.javasdk.ServiceSetup;
import akka.javasdk.DependencyProvider;
import akka.javasdk.annotations.Setup;
import com.example.application.FlureeClient;
import com.typesafe.config.Config;

@Setup
public class Bootstrap implements ServiceSetup {
    private final Config config;
    
    public Bootstrap(Config config) {
        this.config = config;
    }
    
    @Override
    public DependencyProvider createDependencyProvider() {
        final FlureeClient flureeClient = new FlureeClient(config);
        
        return new DependencyProvider() {
            @Override
            public <T> T getDependency(Class<T> clazz) {
                if (clazz == FlureeClient.class) {
                    return (T) flureeClient;
                }
                throw new RuntimeException("No dependency found: " + clazz);
            }
        };
    }
}
import json
import requests
import time

# ============================================================================
# CONFIGURATION
# ============================================================================
API_URL = "http://localhost:58090/fluree/transact"
API_TOKEN = "YOUR_API_TOKEN_HERE"  # Replace with your actual token
LEDGER =  "supply-chain/main"#"fluree-jld/387028092979480"
BATCH_SIZE = 50  # Number of records per API call
NAMESPACE = "https://example.org/"

# ============================================================================
# HEADERS
# ============================================================================
headers = {
    "Content-Type": "application/json",
    # "Authorization": f"Bearer {API_TOKEN}"
}

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def transform_value(key, value):
    """
    Transform a value based on its type and content.
    Handles references to other entities.
    """
    # If value is a string and looks like an entity reference (contains /)
    if isinstance(value, str) and "/" in value and not value.startswith("http"):
        # Check if it's a reference to another entity
        if any(prefix in value for prefix in ["Country/", "Supplier/", "HTSCode/", "Product/", "Recipe/", "Chapter99Provision/", "CBPRuling/"]):
            return {"@id": value}
    
    return value

def transform_record(record):
    """
    Transform a record to include proper namespace prefixes.
    """
    if "@id" not in record:
        print(f"Warning: Record missing @id: {record}")
        return None
    
    # Determine entity type from @id
    entity_id = record["@id"]
    entity_type = entity_id.split("/")[0] if "/" in entity_id else "Unknown"
    
    transformed = {
        "@id": entity_id,
        "@type": f"ex:{entity_type}"
    }
    
    # Transform all properties
    for key, value in record.items():
        if key in ["@id", "ledger", "@type"]:
            continue
        
        # Add namespace prefix
        prefixed_key = f"ex:{key}"
        transformed[prefixed_key] = transform_value(key, value)
    
    return transformed

def group_by_entity_type(records):
    """
    Group records by entity type for ordered insertion.
    Order matters: insert referenced entities first.
    """
    groups = {
        "Country": [],
        "Supplier": [],
        "HTSCode": [],
        "Chapter99Provision": [],
        "CBPRuling": [],
        "Product": [],
        "Recipe": [],
        "Ingredient": [],
        "BOM": []
    }
    
    for record in records:
        if not record or "@id" not in record:
            continue
            
        entity_id = record["@id"]
        entity_type = entity_id.split("/")[0] if "/" in entity_id else None
        
        if entity_type in groups:
            groups[entity_type].append(record)
        else:
            print(f"Warning: Unknown entity type '{entity_type}' for {entity_id}")
    
    return groups

def insert_batch(records, batch_name=""):
    """
    Insert a batch of records via API.
    """
    if not records:
        print(f"No records to insert for {batch_name}")
        return True
    
    payload = {
        "@context": {"ex": NAMESPACE},
        "ledger": LEDGER,
        "insert": records
    }
    
    try:
        response = requests.post(API_URL, headers=headers, json=payload)
        
        if response.status_code == 200:
            print(f"✓ Successfully inserted {len(records)} {batch_name} records")
            return True
        else:
            print(f"✗ Error inserting {batch_name}: {response.status_code}")
            print(f"  Response: {response.text}")
            return False
    
    except Exception as e:
        print(f"✗ Exception inserting {batch_name}: {str(e)}")
        return False

def insert_in_batches(records, entity_type):
    """
    Insert records in batches to avoid overwhelming the API.
    """
    total = len(records)
    if total == 0:
        return True
    
    print(f"\nInserting {total} {entity_type} records...")
    
    success_count = 0
    for i in range(0, total, BATCH_SIZE):
        batch = records[i:i + BATCH_SIZE]
        batch_num = (i // BATCH_SIZE) + 1
        total_batches = (total + BATCH_SIZE - 1) // BATCH_SIZE
        
        print(f"  Batch {batch_num}/{total_batches} ({len(batch)} records)...", end=" ")
        
        if insert_batch(batch, f"{entity_type} batch {batch_num}"):
            success_count += len(batch)
            time.sleep(0.5)  # Small delay between batches
        else:
            print(f"  Stopping at batch {batch_num} due to error")
            break
    
    print(f"✓ Completed {entity_type}: {success_count}/{total} records inserted")
    return success_count == total

# ============================================================================
# MAIN EXECUTION
# ============================================================================

def main():
    print("=" * 70)
    print("FLUREE DATA INSERTION SCRIPT")
    print("=" * 70)
    
    # Load synthetic data
    print("\n1. Loading synthetic data...")
    try:
        with open(r"C:\Users\HP\Downloads\akka-fluree-graph-rag\tradecompliance_seed_transact_payload_fully_validated (1).json", 'r', encoding='utf-8') as f:
            raw_data = json.load(f)
        
        if "insert" in raw_data:
            raw_records = raw_data["insert"]
        else:
            raw_records = raw_data if isinstance(raw_data, list) else [raw_data]
        
        print(f"   Loaded {len(raw_records)} raw records")
    
    except FileNotFoundError:
        print("✗ Error: synthetic_data.json not found!")
        print("  Please ensure the file is in the same directory as this script.")
        return
    except json.JSONDecodeError as e:
        print(f"✗ Error: Invalid JSON in synthetic_data.json: {e}")
        return
    
    # Transform records
    print("\n2. Transforming records to add namespaces...")
    transformed_records = []
    for record in raw_records:
        transformed = transform_record(record)
        if transformed:
            transformed_records.append(transformed)
    
    print(f"   Transformed {len(transformed_records)} records")
    
    # Group by entity type
    print("\n3. Grouping records by entity type...")
    grouped = group_by_entity_type(transformed_records)
    
    for entity_type, records in grouped.items():
        if records:
            print(f"   {entity_type}: {len(records)} records")
    
    # Insert in order (referenced entities first)
    print("\n4. Inserting data into Fluree...")
    print("   (Inserting in dependency order: Countries → Suppliers → etc.)")
    
    insertion_order = [
        "Country",
        "Supplier", 
        "HTSCode",
        "Chapter99Provision",
        "CBPRuling",
        "Recipe",
        "Ingredient",
        "Product",
        "BOM"
    ]
    
    all_success = True
    for entity_type in insertion_order:
        if grouped[entity_type]:
            if not insert_in_batches(grouped[entity_type], entity_type):
                all_success = False
                print(f"\n✗ Failed to insert all {entity_type} records")
                user_input = input("Continue with next entity type? (y/n): ")
                if user_input.lower() != 'y':
                    break
    
    # Summary
    print("\n" + "=" * 70)
    if all_success:
        print("✓ DATA INSERTION COMPLETED SUCCESSFULLY!")
    else:
        print("⚠ DATA INSERTION COMPLETED WITH ERRORS")
    print("=" * 70)
    
    print("\nVerify your data with this query:")
    print(f"""
curl -X POST "https://localhost:58090/fluree/query" \\
-H "Content-Type: application/json" \\
-H "Authorization: Bearer {API_TOKEN}" \\
-d '{{"from": "{LEDGER}", "selectDistinct": "?type", "where": [{{"@id": "?s", "@type": "?type"}}]}}'
    """)

# ============================================================================
# RUN SCRIPT
# ============================================================================

if __name__ == "__main__":
    main()

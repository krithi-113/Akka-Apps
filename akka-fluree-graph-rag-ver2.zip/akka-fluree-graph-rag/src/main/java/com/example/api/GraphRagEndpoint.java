package com.example.api;

import akka.javasdk.annotations.Acl;
import akka.javasdk.annotations.http.HttpEndpoint;
import akka.javasdk.annotations.http.Post;
import akka.javasdk.client.ComponentClient;
import com.example.application.FlureeClient;
import com.example.application.SupplyChainGraphRagAgent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * HTTP API for asking the SupplyChainGraphRagAgent and ingesting data.
 */

@Acl(allow = @Acl.Matcher(principal = Acl.Principal.INTERNET))
@HttpEndpoint("/graph-rag")
public class GraphRagEndpoint {

  private static final Logger log = LoggerFactory.getLogger(GraphRagEndpoint.class);

  // Entity type prefixes that indicate a reference to another entity
  private static final Set<String> ENTITY_PREFIXES = Set.of(
      "Country/", "Supplier/", "HTSCode/", "Product/", "Recipe/",
      "Chapter99Provision/", "CBPRuling/", "Ingredient/", "BOM/"
  );

  public record AskRequest(String question, String sessionId) {}
  public record AskResponse(String sessionId, String answer) {}
  public record IngestRequest(String ledger, List<Map<String, Object>> insert) {}
  public record IngestResponse(boolean success, String message, int recordCount) {}

  private final ComponentClient componentClient;
  private final FlureeClient flureeClient;

  public GraphRagEndpoint(ComponentClient componentClient, FlureeClient flureeClient) {
    this.componentClient = componentClient;
    this.flureeClient = flureeClient;
  }

  @Post("/ask")
  public AskResponse ask(AskRequest request) {
    String sessionId =
        (request.sessionId() == null || request.sessionId().isBlank())
            ? UUID.randomUUID().toString()
            : request.sessionId();

    String answer = componentClient
        .forAgent()
        .inSession(sessionId)
        .method(SupplyChainGraphRagAgent::query)
        .invoke(request.question());

    return new AskResponse(sessionId, answer);
  }

  @Post("/ingest")
  public IngestResponse ingest(IngestRequest request) {
    try {
      if (request.insert() == null || request.insert().isEmpty()) {
        return new IngestResponse(false, "No records to insert", 0);
      }

      log.info("Ingesting {} records", request.insert().size());

      // Transform records: add namespace prefixes and resolve entity references
      List<Map<String, Object>> transformed = new ArrayList<>();
      for (Map<String, Object> record : request.insert()) {
        Map<String, Object> t = transformRecord(record);
        if (t != null) {
          transformed.add(t);
        }
      }

      // Group by entity type for ordered insertion
      String[] insertionOrder = {
          "Country", "Supplier", "HTSCode", "Chapter99Provision",
          "CBPRuling", "Recipe", "Ingredient", "Product", "BOM"
      };
      Set<String> orderedTypes = new LinkedHashSet<>(Arrays.asList(insertionOrder));
      Map<String, List<Map<String, Object>>> grouped = groupByEntityType(transformed);

      int totalInserted = 0;

      // Insert in dependency order
      for (String entityType : insertionOrder) {
        List<Map<String, Object>> batch = grouped.getOrDefault(entityType, List.of());
        if (!batch.isEmpty()) {
          flureeClient.transact(batch);
          totalInserted += batch.size();
          log.info("Inserted {} {} records", batch.size(), entityType);
        }
      }

      // Insert any remaining entity types not in the predefined order
      for (Map.Entry<String, List<Map<String, Object>>> entry : grouped.entrySet()) {
        if (!orderedTypes.contains(entry.getKey()) && !entry.getValue().isEmpty()) {
          flureeClient.transact(entry.getValue());
          totalInserted += entry.getValue().size();
          log.info("Inserted {} {} records", entry.getValue().size(), entry.getKey());
        }
      }

      return new IngestResponse(true, "Successfully ingested " + totalInserted + " records", totalInserted);

    } catch (Exception e) {
      log.error("Ingestion failed", e);
      return new IngestResponse(false, "Ingestion failed: " + e.getMessage(), 0);
    }
  }

  private Map<String, Object> transformRecord(Map<String, Object> record) {
    Object idObj = record.get("@id");
    if (idObj == null) return null;
    String id = idObj.toString();

    String entityType = id.contains("/") ? id.substring(0, id.indexOf("/")) : "Unknown";

    Map<String, Object> result = new HashMap<>();
    result.put("@id", id);
    result.put("@type", "ex:" + entityType);

    for (Map.Entry<String, Object> entry : record.entrySet()) {
      String key = entry.getKey();
      Object value = entry.getValue();

      if (key.equals("@id") || key.equals("@type") || key.equals("ledger")) continue;

      result.put("ex:" + key, transformValue(value));
    }

    return result;
  }

  @SuppressWarnings("unchecked")
  private Object transformValue(Object value) {
    if (value == null) return null;
    if (value instanceof String strVal) {
      if (strVal.contains("/") && !strVal.startsWith("http")) {
        for (String prefix : ENTITY_PREFIXES) {
          if (strVal.startsWith(prefix)) {
            return Map.of("@id", strVal);
          }
        }
      }
    }
    if (value instanceof List<?> listVal) {
      List<Object> transformed = new ArrayList<>();
      for (Object item : listVal) {
        transformed.add(transformValue(item));
      }
      return transformed;
    }
    return value;
  }

  private Map<String, List<Map<String, Object>>> groupByEntityType(List<Map<String, Object>> records) {
    Map<String, List<Map<String, Object>>> groups = new LinkedHashMap<>();
    for (Map<String, Object> record : records) {
      String id = (String) record.get("@id");
      String entityType = (id != null && id.contains("/")) ? id.substring(0, id.indexOf("/")) : "Other";
      groups.computeIfAbsent(entityType, k -> new ArrayList<>()).add(record);
    }
    return groups;
  }
}

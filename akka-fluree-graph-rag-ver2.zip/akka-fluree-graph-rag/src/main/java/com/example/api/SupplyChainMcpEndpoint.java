package com.example.api;

import akka.javasdk.annotations.Acl;
import akka.javasdk.annotations.Description;
import akka.javasdk.annotations.mcp.McpEndpoint;
import akka.javasdk.annotations.mcp.McpTool;
import akka.javasdk.client.ComponentClient;
import com.example.application.SupplyChainGraphRagAgent;

import java.util.UUID;

/**
 * MCP endpoint so external MCP clients can call the SupplyChainGraphRagAgent through /mcp.
 */
@McpEndpoint(serverName = "fluree-supplychain-mcp", serverVersion = "0.1.0")
@Acl(allow = @Acl.Matcher(principal = Acl.Principal.INTERNET))
public class SupplyChainMcpEndpoint {

  private final ComponentClient componentClient;

  public SupplyChainMcpEndpoint(ComponentClient componentClient) {
    this.componentClient = componentClient;
  }

  @McpTool(description = "Ask a question about the hardware supply chain dataset stored in Fluree and get a grounded answer.")
  public String askSupplyChain(
      @Description("Natural language question, e.g. 'Which materials are in Product X and what are their unit prices?'") String question,
      @Description("Optional session id for conversation memory. Leave empty to auto-generate.") String sessionId) {

    String sid = (sessionId == null || sessionId.isBlank()) ? UUID.randomUUID().toString() : sessionId;

    return componentClient.forAgent()
        .inSession(sid)
        .method(SupplyChainGraphRagAgent::query)
        .invoke(question);
  }
}

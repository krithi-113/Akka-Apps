package com.example.application;

import akka.javasdk.agent.ModelProvider;
import dev.langchain4j.model.azure.AzureOpenAiChatModel;
import dev.langchain4j.model.azure.AzureOpenAiStreamingChatModel;

import java.time.Duration;

public final class AzureOpenAiAkkaModelProvider implements ModelProvider.Custom {

  private final String endpoint;        // e.g. https://<resource>.openai.azure.com
  private final String apiKey;          // AZURE_OPENAI_KEY
  private final String deploymentName;  // your Azure deployment name
  private final Duration timeout;

  public AzureOpenAiAkkaModelProvider(String endpoint, String apiKey, String deploymentName, Duration timeout) {
    this.endpoint = endpoint;
    this.apiKey = apiKey;
    this.deploymentName = deploymentName;
    this.timeout = timeout;
  }

  @Override
  public Object createChatModel() {
    System.out.println("Using Azure OpenAI endpoint=" + endpoint + ", deployment=" + deploymentName);
    return AzureOpenAiChatModel.builder()
        .endpoint(endpoint)
        .apiKey(apiKey)
        .deploymentName(deploymentName)
        .timeout(timeout)
        .build();
  }

  @Override
  public Object createStreamingChatModel() {
    return AzureOpenAiStreamingChatModel.builder()
        .endpoint(endpoint)
        .apiKey(apiKey)
        .deploymentName(deploymentName)
        .timeout(timeout)
        .build();
  }
}

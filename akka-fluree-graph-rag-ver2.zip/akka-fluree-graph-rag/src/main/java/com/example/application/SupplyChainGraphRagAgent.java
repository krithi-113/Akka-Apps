package com.example.application;

import akka.javasdk.agent.Agent;
import akka.javasdk.agent.ModelProvider;
import akka.javasdk.annotations.Component;
import akka.javasdk.annotations.Description;
import akka.javasdk.annotations.FunctionTool;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;

@Component(id = "supplychain-graphrag-agent")
public class SupplyChainGraphRagAgent extends Agent {
  private static final Logger log = LoggerFactory.getLogger(SupplyChainGraphRagAgent.class);
  private static final ObjectMapper MAPPER = new ObjectMapper();
  private final FlureeClient fluree;

  private static final String SYSTEM_MESSAGE = """
    You are a supply chain analyst assistant with access to a Fluree graph database
    containing products, suppliers, countries, HTS codes, ingredients, BOMs,
    recipes, Chapter 99 provisions, and CBP rulings.

    Available tools:
    - getAllProducts: Get all products
    - getAllCountries: Get all countries
    - getAllSuppliers: Get all suppliers
    - getAllHTSCodes: Get all HTS classification codes
    - getAllRecipes: Get all recipes
    - getAllIngredients: Get all ingredients
    - getAllChapter99Provisions: Get all Chapter 99 tariff provisions
    - getAllCBPRulings: Get all CBP rulings
    - findProductsByHtsCode: Find products by HTS classification code (e.g. "1901.90.10")
    - findSuppliersByCountry: Find suppliers by ISO country code (e.g. "CN", "US")
    - getProductBOM: Get bill of materials for a product by its @id (e.g. "Product/PROD-001")
    - getProductByName: Get a product by its exact name (e.g. "Precisa Bake 200")
    - getSupplierByName: Get a supplier by its exact name (e.g. "NorthStar Chemicals")

    When answering questions:
    1. Use the appropriate tool to query the Fluree graph database
    2. Parse the JSON response carefully
    3. Provide a clear, concise answer with key details
    4. If data is missing, explain what was searched and suggest alternatives
    5. For compliance questions, check Chapter 99 provisions and CBP rulings

    The database uses entity references like "Country/US", "Supplier/SUP-100", "Product/PROD-001".
    Product IDs look like "Product/PROD-001". HTS codes are strings like "1901.90.10".
    """;

  public SupplyChainGraphRagAgent(FlureeClient fluree) {
    this.fluree = fluree;
  }

  public Effect<String> query(String question) {
    return effects()
        .model(ModelProvider.custom(new AzureOpenAiAkkaModelProvider(
            System.getenv("AZURE_OPENAI_ENDPOINT"),
            System.getenv("AZURE_OPENAI_KEY"),
            System.getenv("AZURE_OPENAI_DEPLOYMENT"),
            Duration.ofSeconds(60)
        )))
        .systemMessage(SYSTEM_MESSAGE)
        .userMessage(question)
        .thenReply();
  }

  // ✅ FIXED: Return JsonNode instead of String
  @FunctionTool(description = "Get all products from the database")
  public JsonNode getAllProducts() {
    log.info("Tool getAllProducts called");
    try {
      String jsonString = fluree.getAllProducts();
      return MAPPER.readTree(jsonString);
    } catch (Exception e) {
      log.error("Error getting all products", e);
      return MAPPER.createObjectNode()
          .put("error", "Failed to retrieve products: " + e.getMessage());
    }
  }

  @FunctionTool(description = "Get all countries from the database")
  public JsonNode getAllCountries() {
    log.info("Tool getAllCountries called");
    try {
      String jsonString = fluree.getAllCountries();
      return MAPPER.readTree(jsonString);
    } catch (Exception e) {
      log.error("Error getting all countries", e);
      return MAPPER.createObjectNode()
          .put("error", "Failed to retrieve countries: " + e.getMessage());
    }
  }

  @FunctionTool(description = "Get all suppliers from the database")
  public JsonNode getAllSuppliers() {
    log.info("Tool getAllSuppliers called");
    try {
      String jsonString = fluree.getAllSuppliers();
      return MAPPER.readTree(jsonString);
    } catch (Exception e) {
      log.error("Error getting all suppliers", e);
      return MAPPER.createObjectNode()
          .put("error", "Failed to retrieve suppliers: " + e.getMessage());
    }
  }

  @FunctionTool(description = "Find products by HTS classification code")
  public JsonNode findProductsByHtsCode(
      @Description("HTS code to search for (e.g. '8517.12.00')") String htsCode) {
    log.info("Tool findProductsByHtsCode called with: {}", htsCode);
    try {
      String jsonString = fluree.findProductsByHtsCode(htsCode);
      return MAPPER.readTree(jsonString);
    } catch (Exception e) {
      log.error("Error finding products by HTS code", e);
      return MAPPER.createObjectNode()
          .put("error", "Failed to find products: " + e.getMessage());
    }
  }

  @FunctionTool(description = "Find suppliers from a specific country")
  public JsonNode findSuppliersByCountry(
      @Description("ISO country code (e.g. 'CN' for China, 'US' for USA)") String countryCode) {
    log.info("Tool findSuppliersByCountry called with: {}", countryCode);
    try {
      String jsonString = fluree.findSuppliersByCountry(countryCode);
      return MAPPER.readTree(jsonString);
    } catch (Exception e) {
      log.error("Error finding suppliers by country", e);
      return MAPPER.createObjectNode()
          .put("error", "Failed to find suppliers: " + e.getMessage());
    }
  }

  @FunctionTool(description = "Get bill of materials (BOM) for a product")
  public JsonNode getProductBOM(
      @Description("Product @id (e.g. 'Product/PROD-001')") String productId) {
    log.info("Tool getProductBOM called with: {}", productId);
    try {
      String jsonString = fluree.getProductBOM(productId);
      return MAPPER.readTree(jsonString);
    } catch (Exception e) {
      log.error("Error getting product BOM", e);
      return MAPPER.createObjectNode()
          .put("error", "Failed to get BOM: " + e.getMessage());
    }
  }

  @FunctionTool(description = "Get all HTS classification codes from the database")
  public JsonNode getAllHTSCodes() {
    log.info("Tool getAllHTSCodes called");
    try {
      String jsonString = fluree.getAllHTSCodes();
      return MAPPER.readTree(jsonString);
    } catch (Exception e) {
      log.error("Error getting all HTS codes", e);
      return MAPPER.createObjectNode()
          .put("error", "Failed to retrieve HTS codes: " + e.getMessage());
    }
  }

  @FunctionTool(description = "Get all recipes from the database")
  public JsonNode getAllRecipes() {
    log.info("Tool getAllRecipes called");
    try {
      String jsonString = fluree.getAllRecipes();
      return MAPPER.readTree(jsonString);
    } catch (Exception e) {
      log.error("Error getting all recipes", e);
      return MAPPER.createObjectNode()
          .put("error", "Failed to retrieve recipes: " + e.getMessage());
    }
  }

  @FunctionTool(description = "Get all ingredients from the database")
  public JsonNode getAllIngredients() {
    log.info("Tool getAllIngredients called");
    try {
      String jsonString = fluree.getAllIngredients();
      return MAPPER.readTree(jsonString);
    } catch (Exception e) {
      log.error("Error getting all ingredients", e);
      return MAPPER.createObjectNode()
          .put("error", "Failed to retrieve ingredients: " + e.getMessage());
    }
  }

  @FunctionTool(description = "Get all Chapter 99 tariff provisions from the database")
  public JsonNode getAllChapter99Provisions() {
    log.info("Tool getAllChapter99Provisions called");
    try {
      String jsonString = fluree.getAllChapter99Provisions();
      return MAPPER.readTree(jsonString);
    } catch (Exception e) {
      log.error("Error getting Chapter 99 provisions", e);
      return MAPPER.createObjectNode()
          .put("error", "Failed to retrieve Chapter 99 provisions: " + e.getMessage());
    }
  }

  @FunctionTool(description = "Get all CBP rulings from the database")
  public JsonNode getAllCBPRulings() {
    log.info("Tool getAllCBPRulings called");
    try {
      String jsonString = fluree.getAllCBPRulings();
      return MAPPER.readTree(jsonString);
    } catch (Exception e) {
      log.error("Error getting CBP rulings", e);
      return MAPPER.createObjectNode()
          .put("error", "Failed to retrieve CBP rulings: " + e.getMessage());
    }
  }

  @FunctionTool(description = "Get a product by its exact name")
  public JsonNode getProductByName(
      @Description("Exact product name (e.g. 'Precisa Bake 200')") String productName) {
    log.info("Tool getProductByName called with: {}", productName);
    try {
      String jsonString = fluree.getProductByName(productName);
      return MAPPER.readTree(jsonString);
    } catch (Exception e) {
      log.error("Error getting product by name", e);
      return MAPPER.createObjectNode()
          .put("error", "Failed to find product: " + e.getMessage());
    }
  }

  @FunctionTool(description = "Get a supplier by its exact name")
  public JsonNode getSupplierByName(
      @Description("Exact supplier name (e.g. 'NorthStar Chemicals')") String supplierName) {
    log.info("Tool getSupplierByName called with: {}", supplierName);
    try {
      String jsonString = fluree.getSupplierByName(supplierName);
      return MAPPER.readTree(jsonString);
    } catch (Exception e) {
      log.error("Error getting supplier by name", e);
      return MAPPER.createObjectNode()
          .put("error", "Failed to find supplier: " + e.getMessage());
    }
  }
}
# Akka Agents + Fluree GraphRAG (Java)

This is a **minimal** Akka Agentic Dev SDK (Java) sample that integrates **Fluree Cloud** as a graph-backed
retrieval/grounding system (GraphRAG style).

What you get:
- `SupplyChainGraphRagAgent` – an Akka `Agent` that answers supply-chain questions using Fluree tools.
- `GraphRagEndpoint` – a simple HTTP endpoint: `POST /graph-rag/ask`
- `SupplyChainMcpEndpoint` – an MCP endpoint so external MCP clients can call the agent via `/mcp`.

> Primary reference: Akka Agentic Dev SDK (your provided context).
> Secondary reference: the Incident Flow Pack sample (Neo4j) for patterns.

---

## 1) Prerequisites

- Java 21
- Maven 3.9+
- A Fluree Cloud account + dataset created using the **Hardware Supply Chain** tutorial dataset
- An LLM API key supported by Akka SDK (example below uses OpenAI)

---

## 2) Configure environment variables

### LLM (OpenAI example)
- `OPENAI_API_KEY`

### Fluree
- `FLUREE_BASE_URL` (optional, default `https://data.flur.ee`)
- `FLUREE_USER_HANDLE` (e.g. `jdoe`)
- `FLUREE_BEARER_TOKEN` (Bearer token used by Fluree Data Agent endpoints)
- `FLUREE_DATASETS` (dataset ids/names, comma-separated. Example: `hardware-supply-chain`)
- `FLUREE_API_KEY` (optional; only needed if you want to use the direct `/api/fluree/query` endpoint)

---

## 3) Run locally

```bash
mvn -q clean compile exec:java -Dexec.mainClass=akka.javasdk.Main
```

Service starts on port **9000** by default.

---

## 4) Ask the agent (HTTP)

```bash
curl -s -X POST http://localhost:9000/graph-rag/ask   -H "Content-Type: application/json"   -d '{"question":"In my Fluree dataset, what are the 3 worst performing products when compared to competitive product pricing?","sessionId":""}'
```

You should get:
```json
{"sessionId":"...","answer":"..."}
```

---

## 5) Ask the agent via MCP tools

Akka exposes MCP endpoints under `/mcp`.

Example (tool invocation endpoint may vary by client; Akka also exposes tools under /mcp/tools/*):

```bash
curl -s -X POST http://localhost:9000/mcp/tools/askSupplyChain   -H "Content-Type: application/json"   -d '{"question":"In my Fluree dataset, which materials are used in Product X?","sessionId":""}'
```

---

## 6) What this sample does (GraphRAG)

The agent has 3 function tools:

- `flureeGenerateAnswer(prompt)` -> calls Fluree `/api/{handle}/generate-answer` (grounded answer JSON)
- `flureeGenerateSparql(prompt)` -> calls Fluree `/api/{handle}/generate-sparql` (query transparency JSON)
- `flureeQuery(flureeQlJson)` -> optional direct FlureeQL query against `/api/fluree/query`

Right now the agent is tuned to:
1) Use `flureeGenerateAnswer` for factual questions
2) Use `flureeGenerateSparql` when the user asks for the query / explanation

---

## 7) Next improvements (recommended)

- Add a deterministic "subgraph retrieval" tool:
  - given a `Product Identifier`, fetch its BOM items + materials + manufacturer + inventory
  - pass that JSON subgraph to the LLM as context
- Add caching (per product/material) to reduce Fluree round-trips
- Add structured output (tables / JSON) for dashboards

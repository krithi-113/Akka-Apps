package com.example.application.ai;

import akka.javasdk.agent.ModelProvider;
// import dev.langchain4j.model.chat.ChatModel;
// import dev.langchain4j.model.chat.StreamingChatModel;
import dev.langchain4j.model.azure.AzureOpenAiChatModel;
import dev.langchain4j.model.azure.AzureOpenAiStreamingChatModel;

import java.time.Duration;

public final class AzureOpenAiAkkaModelProvider implements ModelProvider.Custom {

  private final String endpoint;        // e.g. https://<resource>.openai.azure.com
  private final String apiKey;          // AZURE_OPENAI_KEY
  private final String deploymentName;  // your Azure deployment name (often mapped to a model)
  private final Duration timeout;

  public AzureOpenAiAkkaModelProvider(String endpoint, String apiKey, String deploymentName, Duration timeout) {
    this.endpoint = endpoint;
    this.apiKey = apiKey;
    this.deploymentName = deploymentName;
    this.timeout = timeout;
  }

  @Override
  public Object createChatModel() {
    System.out.println("Using Azure OpenAI endpoint=" + endpoint + ", deployment=" + deploymentName);
    // LangChain4j: endpoint + apiKey required; deploymentName is commonly needed. :contentReference[oaicite:4]{index=4}
    return AzureOpenAiChatModel.builder()
        .endpoint(endpoint)
        .apiKey(apiKey)
        .deploymentName(deploymentName)
        .timeout(timeout)
        // put model params here (temperature/maxTokens/etc) if you want defaults
        .build();
  }

  @Override
  public Object createStreamingChatModel() {
    // If you don’t need streaming you can throw, per Akka docs. :contentReference[oaicite:5]{index=5}
    return AzureOpenAiStreamingChatModel.builder()
        .endpoint(endpoint)
        .apiKey(apiKey)
        .deploymentName(deploymentName)
        .timeout(timeout)
        .build();
  }

  // Convenience accessors if you want (optional)
  // public ChatModel chatModel() { return (ChatModel) createChatModel(); }
  // public StreamingChatModel streamingChatModel() { return (StreamingChatModel) createStreamingChatModel(); }
}

